﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniManage.Data;
using UniManage.Models;

namespace UniManage.Controllers
{
    [Authorize(Roles = "Admin,Lecturer")]
    public class ReportController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public ReportController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);

            // Course popularity
            var courseStats = await _context.Courses
                .Include(c => c.Enrollments)
                .Include(c => c.Lecturer)
                .Select(c => new
                {
                    c.CourseName,
                    EnrollmentCount = c.Enrollments.Count,
                    c.MaxStudents,
                    LecturerName = c.Lecturer.FullName
                }).ToListAsync();

            // Student performance (average grades)
            var studentPerformance = await _context.Submissions
                .Include(s => s.Student)
                .Where(s => s.Grade != null)
                .GroupBy(s => s.Student.FullName)
                .Select(g => new
                {
                    StudentName = g.Key,
                    AverageGrade = g.Average(s => s.Grade)
                }).ToListAsync();

            ViewBag.CourseStats = courseStats;
            ViewBag.StudentPerformance = studentPerformance;
            ViewBag.TotalStudents = (await _userManager.GetUsersInRoleAsync("Student")).Count;
            ViewBag.TotalCourses = await _context.Courses.CountAsync();
            ViewBag.TotalSubmissions = await _context.Submissions.CountAsync();
            ViewBag.GradedSubmissions = await _context.Submissions.CountAsync(s => s.Grade != null);

            return View();
        }
    }
}