﻿namespace UniManage.Models
{
    public class Submission
    {
        public int SubmissionId { get; set; }
        public int AssignmentId { get; set; }
        public Assignment Assignment { get; set; }
        public string StudentId { get; set; } = string.Empty;
        public ApplicationUser Student { get; set; }

        // NEW: stores uploaded PDF path instead of text
        public string FilePath { get; set; } = string.Empty;

        public DateTime SubmittedDate { get; set; }
        public int? Grade { get; set; }
        public string Feedback { get; set; } = string.Empty;
    }
}