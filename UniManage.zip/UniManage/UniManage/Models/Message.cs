﻿using System.ComponentModel.DataAnnotations.Schema;

namespace UniManage.Models
{
    public class Message
    {
        public int MessageId { get; set; }

        public string SenderId { get; set; }

        [ForeignKey("SenderId")]
        public ApplicationUser Sender { get; set; }

        public string ReceiverId { get; set; }

        [ForeignKey("ReceiverId")]
        public ApplicationUser Receiver { get; set; }

        public string Content { get; set; }
        public DateTime SentDate { get; set; }
        public bool IsRead { get; set; }
    }
}