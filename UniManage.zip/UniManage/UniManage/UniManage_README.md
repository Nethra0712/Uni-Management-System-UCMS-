# UniManage

A multi-role university course management system built with **ASP.NET Core MVC (.NET)**. It supports three distinct roles — **Student**, **Lecturer**, and **Admin** — each with their own dashboard, covering course enrollment, assignment submission and grading, internal messaging, and administrative reporting.

## Features

- **Role-based access control** via ASP.NET Core Identity (Student / Lecturer / Admin roles)
- **Course management** — create, view, and enroll in courses with a configurable max student capacity
- **Enrollment system** — students enroll in available courses; lecturers see their own course rosters
- **Assignments** — lecturers post assignments; students upload submission files (PDF)
- **Grading** — lecturers grade student submissions
- **Messaging** — built-in messaging between users
- **Admin dashboard** — manage users, courses, and view system-wide reports
- **Reporting** — course popularity (enrollment counts vs. capacity) and student performance (average grades) via `ReportController`

## Tech Stack

- **Framework:** ASP.NET Core MVC (.NET, C#)
- **Authentication:** ASP.NET Core Identity (`ApplicationUser`, `IdentityRole`)
- **ORM / Database:** Entity Framework Core with SQL Server (`ApplicationDbContext`)
- **Frontend:** Razor Views, Bootstrap, jQuery, jQuery Validation

## Project Structure

```
UniManage/
├── Controllers/
│   ├── AccountController.cs      # Login / Register
│   ├── AdminController.cs        # Admin dashboard & management
│   ├── AssignmentController.cs   # Assignment creation, submission, grading
│   ├── CourseController.cs       # Course CRUD
│   ├── EnrollmentController.cs   # Student course enrollment
│   ├── HomeController.cs
│   ├── MessageController.cs      # Internal messaging
│   └── ReportController.cs       # Admin/Lecturer reporting dashboard
├── Models/
│   ├── ApplicationUser.cs
│   ├── Course.cs
│   ├── Enrollment.cs
│   ├── Assignment.cs
│   ├── Submission.cs
│   └── Message.cs
├── ViewModels/
│   ├── LoginViewModel.cs
│   └── RegisterViewModel.cs
├── Data/
│   └── ApplicationDbContext.cs
├── Migrations/                   # EF Core migration history
├── Views/                        # Razor views per controller
├── wwwroot/
│   ├── lib/                      # Bootstrap, jQuery, jQuery Validation
│   └── uploads/
│       ├── assignments/          # Lecturer-uploaded assignment files
│       └── submissions/          # Student-uploaded submission files (not in repo)
├── appsettings.json
└── UniManage.csproj
```

## Prerequisites

- [.NET SDK](https://dotnet.microsoft.com/download) (matching the version in `UniManage.csproj`)
- SQL Server Express (or full SQL Server) — the default connection string targets `localhost\SQLEXPRESS` with Windows Authentication
- Visual Studio 2022+ (recommended) or VS Code with the C# extension

## Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/<your-username>/UniManage.git
   cd UniManage/UniManage
   ```

2. **Configure the database connection**
   Open `appsettings.json` and update the `DefaultConnection` string if your SQL Server instance name or authentication method differs from the default:
   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Server=localhost\\SQLEXPRESS;Database=UniManageDB;Trusted_Connection=True;TrustServerCertificate=True;"
   }
   ```

3. **Apply database migrations**
   ```bash
   dotnet ef database update
   ```
   This creates the `UniManageDB` database and all required tables (Identity tables, Courses, Enrollments, Assignments, Submissions, Messages).

4. **Run the application**
   ```bash
   dotnet run
   ```
   Or open `UniManage.slnx` in Visual Studio and press **F5**.

5. **Create your first accounts**
   Register through the app's sign-up page, then assign roles (Admin / Lecturer / Student) as needed — either through the Admin dashboard once an admin account exists, or by seeding roles directly in the database.

## Usage

- **Admin:** manage users and courses, view system-wide reports (course popularity, student performance)
- **Lecturer:** create courses and assignments, review and grade student submissions, message students
- **Student:** browse and enroll in courses, submit assignments, view grades, message lecturers

## Notes

- The `wwwroot/uploads/assignments/` and `wwwroot/uploads/submissions/` folders store user-uploaded files at runtime. They're excluded from version control via `.gitignore` since uploaded student submissions may contain personal academic data.
- Build artifacts (`bin/`, `obj/`) and IDE-specific files (`.vs/`, `*.user`) are also excluded — these are regenerated automatically when you build the project.

## License

This project is licensed under the MIT License (or update this section to match the license you select on GitHub).
